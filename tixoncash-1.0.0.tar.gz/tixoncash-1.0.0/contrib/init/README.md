Sample configuration files for:

SystemD: tixoncashd.service
Upstart: tixoncashd.conf
OpenRC:  tixoncashd.openrc
         tixoncashd.openrcconf
CentOS:  tixoncashd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
