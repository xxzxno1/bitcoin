Important notes about v2.2.0 release

- Mandatory update, all users will need to update their client. A resync is not required.
- Syncing should be much quicker. The strict databasing requirement have been relaxed because code has been added that fixes most corruption issues.
- Budget system will now work and the enforcement spork will be turned on.
- Masternode payment system will now work and the enforcement spork will be turned on.
